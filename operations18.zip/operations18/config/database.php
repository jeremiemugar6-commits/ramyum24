<?php
// Suppress all error output to prevent breaking JSON responses
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../error.log');

date_default_timezone_set('Asia/Manila');   // or 'UTC' — pick one and stick with it

// =====================================================================
// CENTRALIZED DATABASE CONFIGURATION
// Database: ram_yum_inventory (consolidated from ramyum_db)
// =====================================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'u479471141_ramyum_db2');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('OTP_DEMO_MODE', true);

// Load environment variables from .env file
function loadEnv($path = __DIR__ . '/../.env') {
    if (!file_exists($path)) {
        return;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        if (!array_key_exists($name, $_ENV)) {
            $_ENV[$name] = $value;
        }
    }
}

// Load environment variables
loadEnv();

// Demo Integration Mode Configuration
define('DEMO_INTEGRATION_MODE', filter_var($_ENV['DEMO_INTEGRATION_MODE'] ?? 'false', FILTER_VALIDATE_BOOLEAN));
define('DEMO_MODE_MESSAGE', $_ENV['DEMO_MODE_MESSAGE'] ?? 'Local demonstration mode is active.');

function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            // Log the error but don't output it
            error_log("Database connection failed: " . $e->getMessage());
            
            // For API endpoints, return a clean error
            if (PHP_SAPI !== 'cli') {
                while (ob_get_level()) {
                    ob_end_clean();
                }
                http_response_code(500);
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => 'Database connection failed']);
                exit;
            }
            throw $e;
        }
    }

    return $pdo;
}

/**
 * Alias for getDB() function for backward compatibility
 * Some legacy files call this function instead of getDB()
 */
function get_database_connection(): PDO
{
    return getDB();
}

/** Alias used by damage-evidence and other endpoints */
function getDBConnection(): PDO
{
    return getDB();
}

/**
 * Get demo integration configuration for frontend
 */
function getDemoConfig(): array
{
    return [
        'demoMode' => DEMO_INTEGRATION_MODE,
        'demoMessage' => DEMO_MODE_MESSAGE
    ];
}