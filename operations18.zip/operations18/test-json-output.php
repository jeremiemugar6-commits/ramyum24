<?php
// Test script to verify JSON output is clean
require_once __DIR__ . '/includes/auth.php';

// This should output clean JSON without any HTML errors
json_response([
    'success' => true,
    'message' => 'JSON output is working correctly',
    'timestamp' => date('Y-m-d H:i:s')
]);
