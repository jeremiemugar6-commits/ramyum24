-- Migration: System Feature Update and Enhancement
-- Date: 2026-11-25
-- Safe updates — does not delete existing data

-- 1. Enhanced login lockout / security review support on users
ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `security_status` ENUM('active','locked_review','unlocked') NOT NULL DEFAULT 'active' AFTER `verified`,
  ADD COLUMN IF NOT EXISTS `lockout_level` TINYINT NOT NULL DEFAULT 0 COMMENT '0=none,1=15min,2=30min,3=review' AFTER `security_status`,
  ADD COLUMN IF NOT EXISTS `locked_until` DATETIME NULL DEFAULT NULL AFTER `lockout_level`,
  ADD COLUMN IF NOT EXISTS `failed_login_count` INT NOT NULL DEFAULT 0 AFTER `locked_until`,
  ADD COLUMN IF NOT EXISTS `last_failed_login_at` DATETIME NULL DEFAULT NULL AFTER `failed_login_count`,
  ADD COLUMN IF NOT EXISTS `last_failed_login_ip` VARCHAR(45) NULL DEFAULT NULL AFTER `last_failed_login_at`;

-- 2. Security notifications for admins
CREATE TABLE IF NOT EXISTS `security_notifications` (
  `id` VARCHAR(40) NOT NULL,
  `type` VARCHAR(50) NOT NULL DEFAULT 'account_lockout',
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `account_identifier` VARCHAR(150) NULL,
  `user_id` VARCHAR(40) NULL,
  `failed_attempts` INT NULL DEFAULT 0,
  `ip_address` VARCHAR(45) NULL,
  `lockout_status` VARCHAR(50) NULL,
  `incident_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('pending','reviewed','unlocked','dismissed') NOT NULL DEFAULT 'pending',
  `reviewed_by` VARCHAR(40) NULL,
  `reviewed_at` DATETIME NULL,
  `review_notes` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Transaction / purchased-sold products archive
CREATE TABLE IF NOT EXISTS `product_transaction_archive` (
  `id` VARCHAR(40) NOT NULL,
  `product_id` VARCHAR(40) NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `sku` VARCHAR(100) NULL,
  `quantity` DECIMAL(15,4) NOT NULL DEFAULT 0,
  `unit` VARCHAR(50) NULL DEFAULT 'Piece',
  `transaction_type` VARCHAR(50) NOT NULL COMMENT 'purchase,sale,issue,receive,adjustment,transfer_out,transfer_in,return',
  `reference_number` VARCHAR(100) NULL,
  `related_user_id` VARCHAR(40) NULL,
  `related_user_name` VARCHAR(150) NULL,
  `remaining_inventory` DECIMAL(15,4) NULL,
  `notes` TEXT NULL,
  `transaction_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_sku` (`sku`),
  KEY `idx_type` (`transaction_type`),
  KEY `idx_date` (`transaction_at`),
  KEY `idx_ref` (`reference_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Terms and Conditions acceptance tracking
CREATE TABLE IF NOT EXISTS `terms_versions` (
  `id` VARCHAR(40) NOT NULL,
  `version` VARCHAR(20) NOT NULL,
  `title` VARCHAR(255) NOT NULL DEFAULT 'Terms and Conditions',
  `content` LONGTEXT NOT NULL,
  `applies_to` VARCHAR(100) NOT NULL DEFAULT 'general' COMMENT 'general,account_activation,inventory_transaction,etc',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` VARCHAR(40) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_version_applies` (`version`,`applies_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `terms_acceptances` (
  `id` VARCHAR(40) NOT NULL,
  `user_id` VARCHAR(40) NOT NULL,
  `terms_id` VARCHAR(40) NOT NULL,
  `terms_version` VARCHAR(20) NOT NULL,
  `applies_to` VARCHAR(100) NOT NULL,
  `accepted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` VARCHAR(45) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_terms` (`terms_id`),
  UNIQUE KEY `uk_user_terms` (`user_id`,`terms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed a default terms version for inventory transactions / account actions
INSERT INTO `terms_versions` (`id`, `version`, `title`, `content`, `applies_to`, `is_active`, `created_by`)
SELECT 'terms_v1_general', '1.0', 'System Terms and Conditions',
'By proceeding with this action, you acknowledge that:
1. All inventory transactions are final and recorded for audit purposes.
2. You are authorized to perform this action under your assigned role.
3. False or fraudulent entries may result in disciplinary action.
4. Data entered must be accurate to the best of your knowledge.
5. The system maintains complete audit trails of all critical operations.',
'general', 1, 'u1'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM terms_versions WHERE id = 'terms_v1_general');

INSERT INTO `terms_versions` (`id`, `version`, `title`, `content`, `applies_to`, `is_active`, `created_by`)
SELECT 'terms_v1_inventory', '1.0', 'Inventory Transaction Agreement',
'I confirm that:
1. The quantities, product details, and reference information I am submitting are accurate.
2. This transaction will be permanently recorded in the system audit log.
3. I understand that inventory adjustments affect stock levels and reports.
4. I am performing this action under proper authorization.',
'inventory_transaction', 1, 'u1'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM terms_versions WHERE id = 'terms_v1_inventory');

-- 5. Enhance login_attempts for progressive lockout tracking
ALTER TABLE `login_attempts`
  ADD COLUMN IF NOT EXISTS `lockout_level` TINYINT NOT NULL DEFAULT 0 AFTER `attempt_count`,
  ADD COLUMN IF NOT EXISTS `locked_until` DATETIME NULL DEFAULT NULL AFTER `lockout_level`,
  ADD COLUMN IF NOT EXISTS `ip_address` VARCHAR(45) NULL DEFAULT NULL AFTER `locked_until`;

-- Note: purchase_orders collection will be treated as purchase_requests via application layer.
-- Existing purchase_orders data is preserved; UI labels and workflows are updated to "Request".
