<?php
/**
 * Safe migration runner for feature updates.
 * Run once from CLI or browser (admin only if web).
 */
require_once __DIR__ . '/../config/database.php';

$db = getDB();

function columnExists(PDO $db, string $table, string $column): bool {
    $stmt = $db->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function tableExists(PDO $db, string $table): bool {
    $stmt = $db->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() > 0;
}

$log = [];

// users columns
$cols = [
    'security_status' => "ENUM('active','locked_review','unlocked') NOT NULL DEFAULT 'active'",
    'lockout_level' => "TINYINT NOT NULL DEFAULT 0",
    'locked_until' => "DATETIME NULL DEFAULT NULL",
    'failed_login_count' => "INT NOT NULL DEFAULT 0",
    'last_failed_login_at' => "DATETIME NULL DEFAULT NULL",
    'last_failed_login_ip' => "VARCHAR(45) NULL DEFAULT NULL",
];
foreach ($cols as $col => $def) {
    if (!columnExists($db, 'users', $col)) {
        $db->exec("ALTER TABLE users ADD COLUMN `{$col}` {$def}");
        $log[] = "Added users.{$col}";
    }
}

// login_attempts columns
$laCols = [
    'lockout_level' => "TINYINT NOT NULL DEFAULT 0",
    'locked_until' => "DATETIME NULL DEFAULT NULL",
    'ip_address' => "VARCHAR(45) NULL DEFAULT NULL",
];
foreach ($laCols as $col => $def) {
    if (!columnExists($db, 'login_attempts', $col)) {
        $db->exec("ALTER TABLE login_attempts ADD COLUMN `{$col}` {$def}");
        $log[] = "Added login_attempts.{$col}";
    }
}

// Tables
$tables = [
    'security_notifications' => "CREATE TABLE `security_notifications` (
  `id` VARCHAR(40) NOT NULL,
  `type` VARCHAR(50) NOT NULL DEFAULT 'account_lockout',
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `account_identifier` VARCHAR(150) NULL,
  `user_id` VARCHAR(40) NULL,
  `failed_attempts` INT NULL DEFAULT 0,
  `ip_address` VARCHAR(45) NULL,
  `lockout_status` VARCHAR(50) NULL,
  `incident_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('pending','reviewed','unlocked','dismissed') NOT NULL DEFAULT 'pending',
  `reviewed_by` VARCHAR(40) NULL,
  `reviewed_at` DATETIME NULL,
  `review_notes` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    'product_transaction_archive' => "CREATE TABLE `product_transaction_archive` (
  `id` VARCHAR(40) NOT NULL,
  `product_id` VARCHAR(40) NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `sku` VARCHAR(100) NULL,
  `quantity` DECIMAL(15,4) NOT NULL DEFAULT 0,
  `unit` VARCHAR(50) NULL DEFAULT 'Piece',
  `transaction_type` VARCHAR(50) NOT NULL,
  `reference_number` VARCHAR(100) NULL,
  `related_user_id` VARCHAR(40) NULL,
  `related_user_name` VARCHAR(150) NULL,
  `remaining_inventory` DECIMAL(15,4) NULL,
  `notes` TEXT NULL,
  `transaction_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_sku` (`sku`),
  KEY `idx_type` (`transaction_type`),
  KEY `idx_date` (`transaction_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    'terms_versions' => "CREATE TABLE `terms_versions` (
  `id` VARCHAR(40) NOT NULL,
  `version` VARCHAR(20) NOT NULL,
  `title` VARCHAR(255) NOT NULL DEFAULT 'Terms and Conditions',
  `content` LONGTEXT NOT NULL,
  `applies_to` VARCHAR(100) NOT NULL DEFAULT 'general',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` VARCHAR(40) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    'terms_acceptances' => "CREATE TABLE `terms_acceptances` (
  `id` VARCHAR(40) NOT NULL,
  `user_id` VARCHAR(40) NOT NULL,
  `terms_id` VARCHAR(40) NOT NULL,
  `terms_version` VARCHAR(20) NOT NULL,
  `applies_to` VARCHAR(100) NOT NULL,
  `accepted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` VARCHAR(45) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_terms` (`terms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
];

foreach ($tables as $name => $sql) {
    if (!tableExists($db, $name)) {
        $db->exec($sql);
        $log[] = "Created table {$name}";
    }
}

// Seed terms
$check = $db->query("SELECT COUNT(*) FROM terms_versions")->fetchColumn();
if ((int)$check === 0) {
    $db->exec("INSERT INTO terms_versions (id, version, title, content, applies_to, is_active, created_by) VALUES
    ('terms_v1_general', '1.0', 'System Terms and Conditions',
     'By proceeding with this action, you acknowledge that:\n1. All inventory transactions are final and recorded for audit purposes.\n2. You are authorized to perform this action under your assigned role.\n3. False or fraudulent entries may result in disciplinary action.\n4. Data entered must be accurate to the best of your knowledge.\n5. The system maintains complete audit trails of all critical operations.',
     'general', 1, 'u1'),
    ('terms_v1_inventory', '1.0', 'Inventory Transaction Agreement',
     'I confirm that:\n1. The quantities, product details, and reference information I am submitting are accurate.\n2. This transaction will be permanently recorded in the system audit log.\n3. I understand that inventory adjustments affect stock levels and reports.\n4. I am performing this action under proper authorization.',
     'inventory_transaction', 1, 'u1')");
    $log[] = 'Seeded default terms versions';
}

header('Content-Type: application/json');
echo json_encode(['success' => true, 'log' => $log ?: ['No changes needed — schema already up to date.']]);
