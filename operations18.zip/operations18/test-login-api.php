<?php
/**
 * Direct test of the login API to see what's being returned
 */

// Simulate a POST request to test the login endpoint
$_SERVER['REQUEST_METHOD'] = 'POST';

// Provide test credentials
$testData = [
    'username' => 'admin',
    'password' => 'admin123'
];

// Simulate JSON input
$GLOBALS['cachedInput'] = $testData;

// Capture the output
ob_start();

try {
    // Include the login script
    include __DIR__ . '/api/login.php';
} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode([
        'test_error' => true,
        'message' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}

$output = ob_get_clean();

// Show what was actually returned
header('Content-Type: text/html');
echo "<!DOCTYPE html><html><head><title>Login API Test</title></head><body>";
echo "<h2>Login API Test Results</h2>";
echo "<h3>Raw Output Length: " . strlen($output) . " bytes</h3>";
echo "<h3>Output (first 500 chars):</h3>";
echo "<pre style='background:#f5f5f5;padding:10px;'>" . htmlspecialchars(substr($output, 0, 500)) . "</pre>";
echo "<h3>Full Output:</h3>";
echo "<pre style='background:#f5f5f5;padding:10px;'>" . htmlspecialchars($output) . "</pre>";

// Try to parse as JSON
echo "<h3>JSON Parse Test:</h3>";
$decoded = json_decode($output, true);
if ($decoded === null) {
    echo "<p style='color:red;'>❌ JSON parsing failed</p>";
    echo "<p>JSON Error: " . json_last_error_msg() . "</p>";
} else {
    echo "<p style='color:green;'>✅ JSON parsed successfully</p>";
    echo "<pre>" . htmlspecialchars(json_encode($decoded, JSON_PRETTY_PRINT)) . "</pre>";
}

echo "</body></html>";
