# System Feature Update and Enhancement

Implemented 2026-11-25. Run the database migration before using new features:

```bash
php database/run-feature-migration.php
# or open that URL once while authenticated as admin (if web-accessible)
```

## 1. Login Security and Account Lockout
- Max failed attempts reduced from **5 → 2**.
- Progressive lockout: 15 min → 30 min → **security review** (admin unlock required).
- In-app security notifications (`api/security-notifications.php`) for admins.
- Failed counter reset on successful login unless under security review.
- Actions logged to `security_logs`.

## 2. OTP Expiration
- OTP TTL reduced from **5 minutes → 60 seconds**.
- Server-side expiry via `expires_at` (MySQL `NOW()`).
- Previous codes invalidated when a new OTP is issued.
- Frontend countdown shows `m:ss` for remaining validity.

## 3. System Diagnostics
- **Reset Demo Data** button and handler removed from Settings → System Diagnostics.

## 4. Purchased / Sold Products Archive
- New table `product_transaction_archive` and API `api/transaction-archive.php`.
- UI module: **Transaction Archive** (sidebar, admin/manager).
- Search/filter by type, date, product, SKU, reference, user.
- Does **not** modify current inventory.

## 5. Admin Password Change
- Requires current password + new + confirm.
- Verified with `password_verify`; stored with `password_hash` (bcrypt).
- Never displays the old password.

## 6. User Profile Password Change
- Profile tab: Current / New / Confirm password fields.
- Same secure API (`api/change-password.php`).
- Message: new password applies on **next login**; session stays active.

## 7. Zero Quantity Products
- Stock field accepts `0`; server rejects only **negative** values.
- Status displays **Out of Stock**; stock can be added later via receiving.

## 8. Purchase Order → Purchase Request
- UI labels, menus, and request numbers (`REQ-YYYY-NNNN`) updated.
- Collection remains `purchase_orders` for DB compatibility.
- Approve/reject workflow retained; **inventory is not increased on approval** — only via Receiving.

## 9. Min / Max Quantity Validation
- Server and client: min ≥ 0; max **must be greater than** min.
- Stock status uses product min/max when set (Low / In / Overstock / Out of Stock).

## 10. Terms and Conditions
- Tables `terms_versions` / `terms_acceptances`.
- API `api/terms.php` + JS helper `assets/js/utils/terms-modal.js`.
- Checkbox defaults **unchecked**; acceptance recorded with user, version, time, IP.
- Seeded default terms for `general` and `inventory_transaction`.

## Files touched (primary)
- `includes/auth.php`, `includes/stock-status.php`, `includes/functions.php`
- `api/login.php`, `api/change-password.php`, `api/security-notifications.php`, `api/transaction-archive.php`, `api/terms.php`, `api/data.php`
- `index.php` (OTP TTL), `modules/settings/settings.js`, `modules/products/catalog.js`
- `modules/purchase-orders/purchase-orders.js`, `modules/dashboard/dashboard.js`, `dashboard.php`
- `modules/archive/archive.js`, `assets/js/utils/stock-status.js`, `assets/js/utils/terms-modal.js`
- `database/migration-feature-updates.sql`, `database/run-feature-migration.php`
