<?php
date_default_timezone_set('Asia/Manila');   // or 'UTC' — pick one and stick with it
/**
 * Session-based authentication for the RAM-YUM PHP backend.
 * Replaces the original app's client-only localStorage "session token".
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/mail.php';
require_once __DIR__ . '/functions.php';

// Start session with error suppression to prevent session warnings from breaking JSON
if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

// Progressive lockout: 2 failed attempts → 15 min, next cycle → 30 min, then security review
const MAX_LOGIN_ATTEMPTS = 2;
const LOCKOUT_MINUTES_LEVEL1 = 15;
const LOCKOUT_MINUTES_LEVEL2 = 30;

const OTP_LENGTH         = 6;
const OTP_TTL_MINUTES    = 1;   // reduced from 5 to 1 minute
const OTP_TTL_SECONDS    = 60;
const OTP_MAX_ATTEMPTS   = 5;
const OTP_RESEND_COOLDOWN_SECONDS = 60;

/**
 * Generates a fresh numeric OTP for the given user, invalidates any
 * previous unconsumed codes for that user/purpose, and stores a hash
 * of the new code (never the plaintext) in the otp_codes table.
 * Returns the plaintext code so the caller can deliver it (email/SMS).
 */
function generate_and_store_otp(string $userId, string $purpose = 'login'): string
{
    $db = getDB();

    // Invalidate any previous outstanding codes for this user/purpose.
    $db->prepare('DELETE FROM otp_codes WHERE user_id = ? AND purpose = ? AND consumed_at IS NULL')
       ->execute([$userId, $purpose]);

    $code = str_pad((string) random_int(0, (10 ** OTP_LENGTH) - 1), OTP_LENGTH, '0', STR_PAD_LEFT);

    // Expire exactly 60 seconds after generation (server-side)
    $stmt = $db->prepare(
        'INSERT INTO otp_codes (id, user_id, code_hash, purpose, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 60 SECOND))'
    );
    $stmt->execute([generate_id('otp'), $userId, password_hash($code, PASSWORD_DEFAULT), $purpose]);

    return $code;
}

/**
 * Returns the number of seconds the caller must still wait before a
 * new OTP may be requested for this user/purpose (0 if none).
 */
function otp_resend_wait_seconds(string $userId, string $purpose = 'login'): int
{
    $db = getDB();
    $stmt = $db->prepare('SELECT created_at FROM otp_codes WHERE user_id = ? AND purpose = ? ORDER BY created_at DESC LIMIT 1');
    $stmt->execute([$userId, $purpose]);
    $row = $stmt->fetch();
    if (!$row) {
        return 0;
    }
    $elapsed = time() - strtotime($row['created_at']);
    return max(0, OTP_RESEND_COOLDOWN_SECONDS - $elapsed);
}

/**
 * Sends an OTP code to the user's email via PHPMailer over SMTP (see
 * config/mail.php for credentials, sourced from .env). Never throws —
 * on any failure (or when SMTP isn't configured) this returns false so
 * the caller can fall back to OTP_DEMO_MODE for local/dev testing.
 */
function send_otp_email(string $email, string $name, string $code): bool
{
    return send_otp_email_smtp($email, $name, $code, OTP_TTL_MINUTES);
}

/**
 * Verifies a submitted OTP code against the latest unconsumed code on
 * file for the user/purpose. Returns one of:
 *   'ok'            — code valid, not expired, under attempt limit; now consumed.
 *   'no_pending'    — no outstanding (unconsumed) code exists for this user.
 *   'expired'       — the latest code exists but its TTL has passed.
 *   'max_attempts'  — the attempt limit was already reached; a new code is required.
 *   'invalid'       — the code was wrong (attempt counter incremented).
 */
function verify_otp_reason(string $userId, string $code, string $purpose = 'login'): string
{
    $db = getDB();
    $stmt = $db->prepare(
        'SELECT * FROM otp_codes WHERE user_id = ? AND purpose = ? AND consumed_at IS NULL ORDER BY created_at DESC LIMIT 1'
    );
    $stmt->execute([$userId, $purpose]);
    $row = $stmt->fetch();

    if (!$row) {
        return 'no_pending';
    }

    if ((int) $row['attempts'] >= OTP_MAX_ATTEMPTS) {
        return 'max_attempts';
    }

    // Server-side expiration check (exactly 60 seconds)
    $check = $db->prepare('SELECT 1 FROM otp_codes WHERE id = ? AND expires_at > NOW()');
    $check->execute([$row['id']]);
    if (!$check->fetch()) {
        return 'expired';
    }

    if (!password_verify($code, $row['code_hash'])) {
        $db->prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?')->execute([$row['id']]);
        return 'invalid';
    }

    $db->prepare('UPDATE otp_codes SET consumed_at = NOW() WHERE id = ?')->execute([$row['id']]);
    return 'ok';
}

/**
 * Back-compat boolean wrapper around verify_otp_reason().
 */
function verify_otp(string $userId, string $code, string $purpose = 'login'): bool
{
    return verify_otp_reason($userId, $code, $purpose) === 'ok';
}

/**
 * Returns true if a user is currently logged in.
 */
function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

/**
 * Fetches the full current user record (minus password hash) from the DB,
 * or null if not logged in / user no longer exists.
 */
function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    $db = getDB();
    $stmt = $db->prepare('SELECT id, name, email, username, role, verified, profile_picture, created_at FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    return $user ?: null;
}

/**
 * Redirects to the login page (for full page loads) if not authenticated.
 * Call this at the top of any protected .php page.
 */
function require_login_page(): array
{
    $user = current_user();
    if (!$user) {
        header('Location: index.php');
        exit;
    }
    return $user;
}

/**
 * For API endpoints: responds with 401 JSON if not authenticated.
 */
function require_login_api(): array
{
    $user = current_user();
    if (!$user) {
        json_error('Not authenticated. Please log in.', 401);
    }
    return $user;
}

/**
 * For API endpoints: responds with 403 JSON if not an admin.
 */
function require_admin_api(): array
{
    $user = require_login_api();
    if ($user['role'] !== 'admin') {
        json_error('Administrator access required.', 403);
    }
    return $user;
}

/**
 * For API endpoints: responds with 403 JSON unless the user is an
 * admin or manager. Used to gate features like AI Analytics that
 * should stay out of reach for staff-level accounts.
 */
function require_manager_api(): array
{
    $user = require_login_api();
    if (!in_array($user['role'], ['admin', 'manager'], true)) {
        json_error('Admin or Manager access required.', 403);
    }
    return $user;
}

/**
 * Get client IP address when available.
 */
function client_ip(): ?string
{
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? null;
    if ($ip && strpos($ip, ',') !== false) {
        $ip = trim(explode(',', $ip)[0]);
    }
    return $ip;
}

/**
 * Checks whether an identifier is currently locked out.
 * Returns [locked(bool), remainingMinutes, statusMessage].
 * Accounts marked for security review remain locked until admin unlocks.
 */
function check_lockout(string $identifier): array
{
    $db = getDB();

    // First check user-level security status (permanent review lock)
    $userStmt = $db->prepare('SELECT id, security_status, lockout_level, locked_until, failed_login_count FROM users WHERE username = ? OR email = ? LIMIT 1');
    $userStmt->execute([$identifier, $identifier]);
    $user = $userStmt->fetch();

    if ($user && ($user['security_status'] ?? 'active') === 'locked_review') {
        return [true, 0, 'Account is restricted pending security review. Contact an administrator.'];
    }

    if ($user && !empty($user['locked_until'])) {
        $lockedUntil = strtotime($user['locked_until']);
        if ($lockedUntil > time()) {
            $remaining = (int) ceil(($lockedUntil - time()) / 60);
            return [true, max(1, $remaining), "Account temporarily locked. Try again in {$remaining} minute(s)."];
        }
    }

    // Fallback to login_attempts table
    $stmt = $db->prepare('SELECT attempt_count, last_attempt, lockout_level, locked_until FROM login_attempts WHERE identifier = ?');
    $stmt->execute([$identifier]);
    $row = $stmt->fetch();

    if (!$row) {
        return [false, 0, ''];
    }

    if (!empty($row['locked_until'])) {
        $lockedUntil = strtotime($row['locked_until']);
        if ($lockedUntil > time()) {
            $remaining = (int) ceil(($lockedUntil - time()) / 60);
            return [true, max(1, $remaining), "Too many failed attempts. Try again in {$remaining} minute(s)."];
        }
    }

    // Legacy simple check
    $elapsedMinutes = (time() - strtotime($row['last_attempt'])) / 60;
    $level = (int) ($row['lockout_level'] ?? 0);
    $lockMinutes = $level >= 2 ? LOCKOUT_MINUTES_LEVEL2 : LOCKOUT_MINUTES_LEVEL1;

    if ((int) $row['attempt_count'] >= MAX_LOGIN_ATTEMPTS && $elapsedMinutes < $lockMinutes) {
        return [true, (int) ceil($lockMinutes - $elapsedMinutes), "Too many failed attempts. Try again in " . (int) ceil($lockMinutes - $elapsedMinutes) . " minute(s)."];
    }

    return [false, 0, ''];
}

/**
 * Records a failed login attempt and applies progressive lockout.
 * Level progression:
 *   2 fails → 15-min lock (level 1)
 *   After level-1 expires + 2 more fails → 30-min lock (level 2)
 *   After level-2 expires + further fails → security review (level 3)
 */
function record_failed_login(string $identifier): void
{
    $db = getDB();
    $ip = client_ip();

    // Resolve user if exists
    $userStmt = $db->prepare('SELECT id, email, username, security_status, lockout_level, failed_login_count, locked_until FROM users WHERE username = ? OR email = ? LIMIT 1');
    $userStmt->execute([$identifier, $identifier]);
    $user = $userStmt->fetch();

    // Upsert login_attempts
    $stmt = $db->prepare(
        'INSERT INTO login_attempts (identifier, attempt_count, last_attempt, lockout_level, ip_address)
         VALUES (?, 1, NOW(), 0, ?)
         ON DUPLICATE KEY UPDATE
            attempt_count = attempt_count + 1,
            last_attempt = NOW(),
            ip_address = VALUES(ip_address)'
    );
    $stmt->execute([$identifier, $ip]);

    $laStmt = $db->prepare('SELECT attempt_count, lockout_level, locked_until FROM login_attempts WHERE identifier = ?');
    $laStmt->execute([$identifier]);
    $la = $laStmt->fetch();
    $attemptCount = (int) ($la['attempt_count'] ?? 1);
    $currentLevel = (int) ($la['lockout_level'] ?? 0);

    // Determine if we need to escalate
    if ($attemptCount >= MAX_LOGIN_ATTEMPTS) {
        if ($currentLevel === 0) {
            // First lockout: 15 minutes
            $db->prepare('UPDATE login_attempts SET lockout_level = 1, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE), attempt_count = 0 WHERE identifier = ?')
               ->execute([LOCKOUT_MINUTES_LEVEL1, $identifier]);
            if ($user) {
                $db->prepare('UPDATE users SET lockout_level = 1, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE), failed_login_count = failed_login_count + ?, last_failed_login_at = NOW(), last_failed_login_ip = ? WHERE id = ?')
                   ->execute([LOCKOUT_MINUTES_LEVEL1, $attemptCount, $ip, $user['id']]);
            }
            log_security_event('ACCOUNT_LOCKED_15MIN', $user['id'] ?? null, $identifier, [
                'attempts' => $attemptCount, 'ip' => $ip, 'duration_minutes' => LOCKOUT_MINUTES_LEVEL1
            ]);
        } elseif ($currentLevel === 1) {
            // Second lockout: 30 minutes
            $db->prepare('UPDATE login_attempts SET lockout_level = 2, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE), attempt_count = 0 WHERE identifier = ?')
               ->execute([LOCKOUT_MINUTES_LEVEL2, $identifier]);
            if ($user) {
                $db->prepare('UPDATE users SET lockout_level = 2, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE), failed_login_count = failed_login_count + ?, last_failed_login_at = NOW(), last_failed_login_ip = ? WHERE id = ?')
                   ->execute([LOCKOUT_MINUTES_LEVEL2, $attemptCount, $ip, $user['id']]);
            }
            log_security_event('ACCOUNT_LOCKED_30MIN', $user['id'] ?? null, $identifier, [
                'attempts' => $attemptCount, 'ip' => $ip, 'duration_minutes' => LOCKOUT_MINUTES_LEVEL2
            ]);
        } else {
            // Level 2+ → security review
            $db->prepare('UPDATE login_attempts SET lockout_level = 3, locked_until = NULL, attempt_count = attempt_count WHERE identifier = ?')
               ->execute([$identifier]);
            if ($user) {
                $db->prepare('UPDATE users SET security_status = ?, lockout_level = 3, locked_until = NULL, failed_login_count = failed_login_count + ?, last_failed_login_at = NOW(), last_failed_login_ip = ? WHERE id = ?')
                   ->execute(['locked_review', $attemptCount, $ip, $user['id']]);
                create_security_notification(
                    $user['id'],
                    $user['email'] ?? $identifier,
                    $attemptCount,
                    $ip,
                    'locked_review'
                );
            }
            log_security_event('ACCOUNT_SECURITY_REVIEW', $user['id'] ?? null, $identifier, [
                'attempts' => $attemptCount, 'ip' => $ip, 'status' => 'locked_review'
            ]);
        }
    } elseif ($user) {
        $db->prepare('UPDATE users SET failed_login_count = failed_login_count + 1, last_failed_login_at = NOW(), last_failed_login_ip = ? WHERE id = ?')
           ->execute([$ip, $user['id']]);
    }
}

/**
 * Create an in-app security notification for admins.
 */
function create_security_notification(?string $userId, string $identifier, int $failedAttempts, ?string $ip, string $status): void
{
    $db = getDB();
    $id = generate_id('secnote');
    $title = 'Security Alert: Account Locked';
    $message = 'Account "' . $identifier . '" has been locked after repeated failed login attempts.';
    $stmt = $db->prepare(
        'INSERT INTO security_notifications (id, type, title, message, account_identifier, user_id, failed_attempts, ip_address, lockout_status, incident_at, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)'
    );
    $stmt->execute([
        $id, 'account_lockout', $title, $message, $identifier, $userId,
        $failedAttempts, $ip, $status, 'pending'
    ]);
}

/**
 * Clears recorded failed login attempts after a successful login,
 * but only if the account is not under security review.
 */
function clear_login_attempts(string $identifier): void
{
    $db = getDB();

    $userStmt = $db->prepare('SELECT id, security_status FROM users WHERE username = ? OR email = ? LIMIT 1');
    $userStmt->execute([$identifier, $identifier]);
    $user = $userStmt->fetch();

    if ($user && ($user['security_status'] ?? 'active') === 'locked_review') {
        // Do not clear while under review
        return;
    }

    $db->prepare('DELETE FROM login_attempts WHERE identifier = ?')->execute([$identifier]);

    if ($user) {
        $db->prepare('UPDATE users SET failed_login_count = 0, lockout_level = 0, locked_until = NULL, last_failed_login_at = NULL, last_failed_login_ip = NULL WHERE id = ? AND security_status != ?')
           ->execute([$user['id'], 'locked_review']);
    }
}

/**
 * Admin unlocks an account that was under security review.
 */
function admin_unlock_account(string $userId, string $adminId, string $notes = ''): bool
{
    $db = getDB();
    $stmt = $db->prepare('UPDATE users SET security_status = ?, lockout_level = 0, locked_until = NULL, failed_login_count = 0 WHERE id = ?');
    $stmt->execute(['active', $userId]);

    // Clear login attempts for this user
    $u = $db->prepare('SELECT username, email FROM users WHERE id = ?');
    $u->execute([$userId]);
    $row = $u->fetch();
    if ($row) {
        $db->prepare('DELETE FROM login_attempts WHERE identifier IN (?, ?)')->execute([$row['username'], $row['email']]);
    }

    // Mark related notifications as unlocked
    $db->prepare('UPDATE security_notifications SET status = ?, reviewed_by = ?, reviewed_at = NOW(), review_notes = ? WHERE user_id = ? AND status = ?')
       ->execute(['unlocked', $adminId, $notes, $userId, 'pending']);

    log_security_event('ACCOUNT_UNLOCKED_BY_ADMIN', $adminId, null, [
        'target_user_id' => $userId,
        'notes' => $notes
    ]);
    return true;
}
