<?php
/**
 * Stock Status Helper
 * Centralized logic for automatic stock status calculation
 * Prefer product min/max when provided; fall back to legacy thresholds.
 */

/**
 * Get automatic stock status based on current quantity and optional min/max.
 *
 * Rules (when min/max provided):
 * - stock <= 0          → Out of Stock
 * - stock < minimum     → Low Stock
 * - stock > maximum     → Overstock
 * - otherwise           → In Stock
 *
 * Legacy fallback (no min/max):
 * - 0 = Out of Stock
 * - 1-20 = Low Stock
 * - 21-100 = In Stock
 * - 101+ = Overstock
 */
function getStockStatus($currentStock, $minimumStock = null, $maximumStock = null)
{
    $stock = floatval($currentStock);

    if ($stock <= 0) {
        return 'Out of Stock';
    }

    $hasMin = $minimumStock !== null && $minimumStock !== '' && is_numeric($minimumStock);
    $hasMax = $maximumStock !== null && $maximumStock !== '' && is_numeric($maximumStock);

    if ($hasMin || $hasMax) {
        $min = $hasMin ? floatval($minimumStock) : 0;
        $max = $hasMax ? floatval($maximumStock) : PHP_FLOAT_MAX;

        if ($stock < $min) {
            return 'Low Stock';
        }
        if ($stock > $max) {
            return 'Overstock';
        }
        return 'In Stock';
    }

    // Legacy thresholds
    if ($stock < 21) {
        return 'Low Stock';
    }
    if ($stock <= 100) {
        return 'In Stock';
    }
    return 'Overstock';
}

/**
 * Validate min/max quantity pair.
 * Returns error message string or null if valid.
 */
function validateMinMaxQuantity($min, $max): ?string
{
    if ($min === null || $min === '') {
        return null; // optional
    }
    if (!is_numeric($min) || floatval($min) < 0) {
        return 'Minimum Quantity must be a valid non-negative number.';
    }
    if ($max !== null && $max !== '') {
        if (!is_numeric($max)) {
            return 'Maximum Quantity must be a valid number.';
        }
        if (floatval($max) <= floatval($min)) {
            return 'Maximum Quantity must be greater than Minimum Quantity.';
        }
    }
    return null;
}

function getStockStatusBadge($currentStock, $minimumStock = null, $maximumStock = null)
{
    $status = getStockStatus($currentStock, $minimumStock, $maximumStock);
    $badgeClass = getStockStatusBadgeClass($status);
    $emoji = getStockStatusEmoji($status);

    return "<span class=\"stock-badge {$badgeClass}\">{$emoji} {$status}</span>";
}

function getStockStatusBadgeClass($status)
{
    switch ($status) {
        case 'Out of Stock':
            return 'badge-out-of-stock';
        case 'Low Stock':
            return 'badge-low-stock';
        case 'In Stock':
            return 'badge-in-stock';
        case 'Overstock':
            return 'badge-overstock';
        default:
            return 'badge-default';
    }
}

function getStockStatusEmoji($status)
{
    switch ($status) {
        case 'Out of Stock':
            return '🔴';
        case 'Low Stock':
            return '🟠';
        case 'In Stock':
            return '🟢';
        case 'Overstock':
            return '🔵';
        default:
            return '⚪';
    }
}

function getProductStockStatus($productData)
{
    $stock = $productData['stock'] ?? 0;
    $min = $productData['minimumStock'] ?? $productData['minStock'] ?? null;
    $max = $productData['maximumStock'] ?? $productData['maxStock'] ?? null;
    return getStockStatus($stock, $min, $max);
}
