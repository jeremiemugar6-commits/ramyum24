<?php
// Debug version - shows actual errors
error_reporting(E_ALL);
ini_set('display_errors', '1');

header('Content-Type: application/json');

try {
    echo "Starting login process...\n";
    
    require_once __DIR__ . '/../includes/auth.php';
    echo "Auth included...\n";

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Method not allowed');
    }

    $input = get_json_input();
    echo "Input received: " . json_encode($input) . "\n";
    
    $identifier = trim($input['username'] ?? '');
    $password   = (string) ($input['password'] ?? '');

    if ($identifier === '' || $password === '') {
        throw new Exception('Username/email and password are required');
    }

    echo "Checking lockout...\n";
    [$locked, $remainingMinutes, $lockMessage] = check_lockout(strtolower($identifier));
    if ($locked) {
        throw new Exception($lockMessage);
    }

    echo "Getting database...\n";
    $db = getDB();
    
    echo "Querying user...\n";
    $stmt = $db->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
    $stmt->execute([$identifier, $identifier]);
    $user = $stmt->fetch();

    if (!$user) {
        throw new Exception('User not found');
    }

    echo "User found: " . $user['username'] . "\n";
    
    if (!password_verify($password, $user['password_hash'])) {
        throw new Exception('Password verification failed');
    }

    echo "Password verified...\n";

    if (!$user['verified']) {
        throw new Exception('Account not verified');
    }

    if (($user['security_status'] ?? 'active') === 'locked_review') {
        throw new Exception('Account locked for review');
    }

    echo "Regenerating session...\n";
    session_regenerate_id(true);
    $_SESSION['otp_pending_user_id'] = $user['id'];
    unset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['role']);

    echo "Clearing login attempts...\n";
    clear_login_attempts(strtolower($identifier));

    echo "Generating OTP...\n";
    $otpCode = generate_and_store_otp($user['id']);
    
    echo "Sending email...\n";
    $mailed  = send_otp_email($user['email'], $user['name'], $otpCode);
    
    echo "Logging event...\n";
    log_security_event('OTP_SENT', $user['id'], $user['username'], ['mailed' => $mailed]);

    $response = [
        'success'     => true,
        'requiresOtp' => true,
        'otpTtlSeconds' => 60,
        'maskedEmail' => mask_email($user['email']),
        'debugCode' => $otpCode,
        'debug_mailed' => $mailed
    ];

    echo "\n\nFinal response:\n";
    echo json_encode($response, JSON_PRETTY_PRINT);

} catch (Throwable $e) {
    echo "\n\nERROR CAUGHT:\n";
    echo "Message: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "\nTrace:\n" . $e->getTraceAsString();
}
