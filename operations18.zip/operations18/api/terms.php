<?php
/**
 * Terms and Conditions API
 * - GET active terms by applies_to
 * - POST accept terms
 * - Admin can manage versions
 */
require_once __DIR__ . '/../includes/auth.php';

$user = require_login_api();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $appliesTo = $_GET['applies_to'] ?? 'general';
    $action = $_GET['action'] ?? 'active';

    if ($action === 'check') {
        // Has the current user accepted the latest active terms for this context?
        $stmt = $db->prepare(
            'SELECT tv.id, tv.version, tv.title, tv.content, tv.applies_to
             FROM terms_versions tv
             WHERE tv.applies_to = ? AND tv.is_active = 1
             ORDER BY tv.created_at DESC LIMIT 1'
        );
        $stmt->execute([$appliesTo]);
        $terms = $stmt->fetch();
        if (!$terms) {
            json_response(['success' => true, 'required' => false, 'terms' => null]);
        }
        $acc = $db->prepare('SELECT id, accepted_at FROM terms_acceptances WHERE user_id = ? AND terms_id = ?');
        $acc->execute([$user['id'], $terms['id']]);
        $accepted = $acc->fetch();
        json_response([
            'success' => true,
            'required' => !$accepted,
            'terms' => $terms,
            'accepted_at' => $accepted['accepted_at'] ?? null,
        ]);
    }

    // Default: return active terms
    $stmt = $db->prepare(
        'SELECT id, version, title, content, applies_to, created_at
         FROM terms_versions WHERE applies_to = ? AND is_active = 1
         ORDER BY created_at DESC LIMIT 1'
    );
    $stmt->execute([$appliesTo]);
    $terms = $stmt->fetch();
    json_response(['success' => true, 'terms' => $terms]);
}

if ($method === 'POST') {
    $input = get_json_input();
    $action = $input['action'] ?? 'accept';

    if ($action === 'accept') {
        $termsId = $input['terms_id'] ?? '';
        if ($termsId === '') {
            json_error('terms_id is required.');
        }
        $stmt = $db->prepare('SELECT * FROM terms_versions WHERE id = ? AND is_active = 1');
        $stmt->execute([$termsId]);
        $terms = $stmt->fetch();
        if (!$terms) {
            json_error('Terms not found or inactive.', 404);
        }

        $id = generate_id('tacc');
        $ip = client_ip();
        // Upsert acceptance
        $db->prepare('DELETE FROM terms_acceptances WHERE user_id = ? AND terms_id = ?')->execute([$user['id'], $termsId]);
        $ins = $db->prepare(
            'INSERT INTO terms_acceptances (id, user_id, terms_id, terms_version, applies_to, accepted_at, ip_address)
             VALUES (?, ?, ?, ?, ?, NOW(), ?)'
        );
        $ins->execute([$id, $user['id'], $termsId, $terms['version'], $terms['applies_to'], $ip]);

        log_security_event('TERMS_ACCEPTED', $user['id'], $user['username'], [
            'terms_id' => $termsId,
            'version' => $terms['version'],
            'applies_to' => $terms['applies_to'],
        ]);

        json_response(['success' => true, 'message' => 'Terms accepted.']);
    }

    if ($action === 'create' || $action === 'update') {
        require_admin_api();
        $version = trim($input['version'] ?? '');
        $title = trim($input['title'] ?? 'Terms and Conditions');
        $content = trim($input['content'] ?? '');
        $appliesTo = trim($input['applies_to'] ?? 'general');
        if ($version === '' || $content === '') {
            json_error('version and content are required.');
        }
        $id = $input['id'] ?? generate_id('terms');
        // Deactivate previous active for same applies_to if setting new active
        if (!empty($input['is_active'])) {
            $db->prepare('UPDATE terms_versions SET is_active = 0 WHERE applies_to = ?')->execute([$appliesTo]);
        }
        $stmt = $db->prepare(
            'INSERT INTO terms_versions (id, version, title, content, applies_to, is_active, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE title = VALUES(title), content = VALUES(content), is_active = VALUES(is_active)'
        );
        $stmt->execute([$id, $version, $title, $content, $appliesTo, !empty($input['is_active']) ? 1 : 1, $user['id']]);
        log_security_event('TERMS_UPDATED', $user['id'], $user['username'], ['terms_id' => $id, 'version' => $version]);
        json_response(['success' => true, 'id' => $id]);
    }

    json_error('Unknown action.');
}

json_error('Method not allowed.', 405);
