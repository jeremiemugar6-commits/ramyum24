<?php
/**
 * Supplier performance scorecard derived from POs, receivings, and POR data.
 */
require_once __DIR__ . '/../includes/auth.php';
require_login_api();

$db = getDB();
$scorecards = [];

// Load suppliers
$suppliers = [];
try {
    $stmt = $db->query('SELECT id, data FROM suppliers');
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $s = json_decode($row['data'], true) ?: [];
        $id = $s['id'] ?? $row['id'];
        $suppliers[$id] = [
            'id' => $id,
            'name' => $s['company'] ?? $s['name'] ?? 'Unknown',
            'contact' => $s['contactPerson'] ?? '',
            'email' => $s['email'] ?? '',
            'poCount' => 0,
            'receivedCount' => 0,
            'totalOrdered' => 0,
            'totalReceived' => 0,
            'totalRejected' => 0,
            'totalDamaged' => 0,
            'onTime' => 0,
            'late' => 0,
        ];
    }
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => $e->getMessage()], 500);
}

// Aggregate from purchase orders
try {
    $stmt = $db->query('SELECT id, data FROM purchase_orders');
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $po = json_decode($row['data'], true) ?: [];
        $sid = $po['supplierId'] ?? $po['supplier_id'] ?? null;
        // fallback: match by supplier name
        if (!$sid || !isset($suppliers[$sid])) {
            $sname = mb_strtolower($po['supplier'] ?? $po['supplierName'] ?? '');
            foreach ($suppliers as $id => $s) {
                if (mb_strtolower($s['name']) === $sname) { $sid = $id; break; }
            }
        }
        if (!$sid || !isset($suppliers[$sid])) continue;

        $suppliers[$sid]['poCount']++;
        $items = $po['items'] ?? [];
        foreach ($items as $it) {
            $suppliers[$sid]['totalOrdered'] += floatval($it['quantity'] ?? $it['orderedQty'] ?? 0);
        }
    }
} catch (Throwable $e) { /* skip */ }

// Aggregate from inventory movements (POR accepts/rejects)
try {
    $stmt = $db->query('SELECT data FROM inventory_movements');
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $d = json_decode($row['data'], true) ?: [];
        $notes = $d['notes'] ?? '';
        $reason = $d['reason'] ?? '';
        // Try to find supplier name in notes: "Supplier: X |"
        if (preg_match('/Supplier:\s*([^|]+)/i', $notes, $m)) {
            $sname = trim($m[1]);
            $sid = null;
            foreach ($suppliers as $id => $s) {
                if (strcasecmp($s['name'], $sname) === 0) { $sid = $id; break; }
            }
            if (!$sid) continue;

            $qty = abs(floatval($d['quantity'] ?? $d['change'] ?? 0));
            $type = strtolower($d['type'] ?? '');
            if (str_contains(strtolower($reason), 'accept') || $type === 'stock in') {
                $suppliers[$sid]['totalReceived'] += $qty;
                $suppliers[$sid]['receivedCount']++;
            }
            if (preg_match('/Rejected:\s*(\d+)/i', $notes, $rm)) {
                $suppliers[$sid]['totalRejected'] += intval($rm[1]);
            }
            if (preg_match('/Damaged:\s*(\d+)/i', $notes, $dm)) {
                $suppliers[$sid]['totalDamaged'] += intval($dm[1]);
            }
        }
    }
} catch (Throwable $e) { /* skip */ }

// Compute scores
foreach ($suppliers as $id => &$s) {
    $ordered = max($s['totalOrdered'], 1);
    $fillRate = min(100, round(($s['totalReceived'] / $ordered) * 100, 1));
    $rejectRate = $s['totalReceived'] > 0
        ? round(($s['totalRejected'] / max($s['totalReceived'] + $s['totalRejected'], 1)) * 100, 1)
        : 0;
    // Simple quality score: 100 - reject% - damage penalty
    $quality = max(0, round(100 - $rejectRate - ($s['totalDamaged'] * 2), 1));
    $s['fillRate'] = $fillRate;
    $s['rejectRate'] = $rejectRate;
    $s['qualityScore'] = $quality;
    $s['overallScore'] = round(($fillRate * 0.4 + $quality * 0.6), 1);
}
unset($s);

// Sort by overall score desc
$list = array_values($suppliers);
usort($list, fn($a, $b) => $b['overallScore'] <=> $a['overallScore']);

json_response(['success' => true, 'data' => $list]);
