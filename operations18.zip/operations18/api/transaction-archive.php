<?php
/**
 * Purchased / Sold Products Archive API
 * Historical transaction records — does not modify inventory.
 */
require_once __DIR__ . '/../includes/auth.php';

$user = require_login_api();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

// Only owner/admin/manager can view archive (staff may be restricted)
$role = $user['role'] ?? 'staff';
if (!in_array($role, ['admin', 'manager'], true) && $method !== 'GET') {
    // Allow staff to GET if needed; writes are system-driven
}

if ($method === 'GET') {
    $productId = $_GET['product_id'] ?? null;
    $sku = $_GET['sku'] ?? null;
    $type = $_GET['type'] ?? null;
    $q = trim($_GET['q'] ?? '');
    $from = $_GET['from'] ?? null;
    $to = $_GET['to'] ?? null;
    $limit = min(500, max(1, (int) ($_GET['limit'] ?? 100)));

    $sql = 'SELECT * FROM product_transaction_archive WHERE 1=1';
    $params = [];

    if ($productId) {
        $sql .= ' AND product_id = ?';
        $params[] = $productId;
    }
    if ($sku) {
        $sql .= ' AND sku = ?';
        $params[] = $sku;
    }
    if ($type) {
        $sql .= ' AND transaction_type = ?';
        $params[] = $type;
    }
    if ($q !== '') {
        $sql .= ' AND (product_name LIKE ? OR sku LIKE ? OR reference_number LIKE ? OR related_user_name LIKE ?)';
        $like = '%' . $q . '%';
        $params = array_merge($params, [$like, $like, $like, $like]);
    }
    if ($from) {
        $sql .= ' AND transaction_at >= ?';
        $params[] = $from;
    }
    if ($to) {
        $sql .= ' AND transaction_at <= ?';
        $params[] = $to . ' 23:59:59';
    }

    $sql .= ' ORDER BY transaction_at DESC LIMIT ' . (int) $limit;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    json_response(['success' => true, 'records' => $rows, 'count' => count($rows)]);
}

if ($method === 'POST') {
    // System or authorized user can record a transaction
    $input = get_json_input();
    $required = ['product_name', 'quantity', 'transaction_type'];
    foreach ($required as $f) {
        if (empty($input[$f]) && $input[$f] !== 0 && $input[$f] !== '0') {
            json_error("Field '{$f}' is required.");
        }
    }

    $id = generate_id('pta');
    $stmt = $db->prepare(
        'INSERT INTO product_transaction_archive
         (id, product_id, product_name, sku, quantity, unit, transaction_type, reference_number,
          related_user_id, related_user_name, remaining_inventory, notes, transaction_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, COALESCE(?, NOW()))'
    );
    $stmt->execute([
        $id,
        $input['product_id'] ?? null,
        $input['product_name'],
        $input['sku'] ?? null,
        (float) $input['quantity'],
        $input['unit'] ?? 'Piece',
        $input['transaction_type'],
        $input['reference_number'] ?? null,
        $input['related_user_id'] ?? $user['id'],
        $input['related_user_name'] ?? $user['name'],
        isset($input['remaining_inventory']) ? (float) $input['remaining_inventory'] : null,
        $input['notes'] ?? null,
        $input['transaction_at'] ?? null,
    ]);

    log_security_event('TRANSACTION_ARCHIVED', $user['id'], $user['username'], [
        'archive_id' => $id,
        'type' => $input['transaction_type'],
        'product' => $input['product_name'],
    ]);

    json_response(['success' => true, 'id' => $id], 201);
}

json_error('Method not allowed.', 405);
