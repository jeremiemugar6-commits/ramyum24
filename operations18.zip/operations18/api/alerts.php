<?php
/**
 * Operational alerts: low stock + approaching/expired items.
 * GET → { success, data: { lowStock: [], expiring: [], expired: [], summary: {} } }
 */
require_once __DIR__ . '/../includes/auth.php';
require_login_api();

$db = getDB();
$now = new DateTime('now');

$lowStock = [];
$expiring = []; // within 30 days
$expired  = [];

try {
    $stmt = $db->query('SELECT id, data FROM products');
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $row) {
        $p = json_decode($row['data'], true);
        if (!$p || !empty($p['archived'])) continue;

        $stock = floatval($p['stock'] ?? 0);
        $reorder = floatval($p['reorderLevel'] ?? $p['minimumStock'] ?? 10);
        $name = $p['name'] ?? 'Unknown';
        $sku  = $p['sku'] ?? '';
        $id   = $p['id'] ?? $row['id'];

        if ($stock <= 0) {
            $lowStock[] = [
                'id' => $id, 'name' => $name, 'sku' => $sku,
                'stock' => $stock, 'reorderLevel' => $reorder,
                'severity' => 'out_of_stock',
                'message' => "$name is out of stock",
            ];
        } elseif ($stock <= $reorder) {
            $lowStock[] = [
                'id' => $id, 'name' => $name, 'sku' => $sku,
                'stock' => $stock, 'reorderLevel' => $reorder,
                'severity' => 'low_stock',
                'message' => "$name is low ($stock / reorder $reorder)",
            ];
        }

        $expStr = $p['expirationDate'] ?? $p['expiration_date'] ?? null;
        if ($expStr) {
            try {
                $exp = new DateTime($expStr);
                $diff = (int)$now->diff($exp)->format('%r%a');
                $item = [
                    'id' => $id, 'name' => $name, 'sku' => $sku,
                    'stock' => $stock,
                    'expirationDate' => $exp->format('Y-m-d'),
                    'daysLeft' => $diff,
                    'batchNumber' => $p['batchNumber'] ?? null,
                    'manufacturingDate' => $p['manufacturingDate'] ?? $p['manufacturing_date'] ?? null,
                ];
                if ($diff < 0) {
                    $item['severity'] = 'expired';
                    $item['message'] = "$name expired " . abs($diff) . " day(s) ago";
                    $expired[] = $item;
                } elseif ($diff <= 30) {
                    $item['severity'] = $diff <= 7 ? 'critical' : 'soon';
                    $item['message'] = "$name expires in $diff day(s)";
                    $expiring[] = $item;
                }
            } catch (Throwable $e) { /* skip bad dates */ }
        }
    }
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => $e->getMessage()], 500);
}

// Sort
usort($lowStock, fn($a, $b) => $a['stock'] <=> $b['stock']);
usort($expiring, fn($a, $b) => $a['daysLeft'] <=> $b['daysLeft']);
usort($expired, fn($a, $b) => $a['daysLeft'] <=> $b['daysLeft']);

json_response([
    'success' => true,
    'data' => [
        'lowStock'  => $lowStock,
        'expiring'  => $expiring,
        'expired'   => $expired,
        'summary'   => [
            'lowStockCount' => count($lowStock),
            'expiringCount' => count($expiring),
            'expiredCount'  => count($expired),
            'total'         => count($lowStock) + count($expiring) + count($expired),
        ],
    ],
]);
