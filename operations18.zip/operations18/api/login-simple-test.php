<?php
// Simplest possible test - step by step
error_reporting(E_ALL);
ini_set('display_errors', '1');
header('Content-Type: text/plain');

echo "=== LOGIN SIMPLE TEST ===\n\n";

// Step 1: Test basic PHP
echo "1. PHP Version: " . PHP_VERSION . " ✓\n";

// Step 2: Test POST data
echo "2. Request method: " . $_SERVER['REQUEST_METHOD'] . "\n";
$rawInput = file_get_contents('php://input');
echo "3. Raw input length: " . strlen($rawInput) . " bytes\n";
echo "4. Raw input: " . $rawInput . "\n";

// Step 3: Parse JSON
$input = json_decode($rawInput, true);
if ($input === null) {
    echo "5. JSON parse: FAILED - " . json_last_error_msg() . " ✗\n";
    exit;
}
echo "5. JSON parse: SUCCESS ✓\n";
echo "6. Username: " . ($input['username'] ?? 'missing') . "\n";
echo "7. Password: " . (isset($input['password']) ? '[present]' : 'missing') . "\n\n";

// Step 4: Test requires
echo "=== TESTING INCLUDES ===\n";
try {
    require_once __DIR__ . '/../config/database.php';
    echo "8. database.php: ✓\n";
} catch (Throwable $e) {
    echo "8. database.php: ✗ " . $e->getMessage() . "\n";
    exit;
}

try {
    require_once __DIR__ . '/../config/mail.php';
    echo "9. mail.php: ✓\n";
} catch (Throwable $e) {
    echo "9. mail.php: ✗ " . $e->getMessage() . "\n";
    exit;
}

try {
    require_once __DIR__ . '/../includes/functions.php';
    echo "10. functions.php: ✓\n";
} catch (Throwable $e) {
    echo "10. functions.php: ✗ " . $e->getMessage() . "\n";
    exit;
}

// Step 5: Test session
echo "\n=== TESTING SESSION ===\n";
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "11. Session already active ✓\n";
} else {
    @session_start();
    if (session_status() === PHP_SESSION_ACTIVE) {
        echo "11. Session started ✓\n";
    } else {
        echo "11. Session failed ✗\n";
    }
}

// Step 6: Test database
echo "\n=== TESTING DATABASE ===\n";
try {
    $db = getDB();
    echo "12. Database connection: ✓\n";
    
    $stmt = $db->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch();
    echo "13. Users table accessible: ✓ (" . $result['count'] . " users)\n";
    
    $stmt = $db->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
    $stmt->execute(['admin']);
    $user = $stmt->fetch();
    
    if ($user) {
        echo "14. Admin user found: ✓\n";
        echo "    - ID: " . $user['id'] . "\n";
        echo "    - Username: " . $user['username'] . "\n";
        echo "    - Name: " . $user['name'] . "\n";
        echo "    - Email: " . $user['email'] . "\n";
        echo "    - Role: " . $user['role'] . "\n";
        echo "    - Verified: " . ($user['verified'] ? 'Yes' : 'No') . "\n";
        
        // Test password verification
        if (isset($input['password'])) {
            if (password_verify($input['password'], $user['password_hash'])) {
                echo "15. Password verification: ✓\n";
            } else {
                echo "15. Password verification: ✗ (password incorrect)\n";
            }
        }
    } else {
        echo "14. Admin user: NOT FOUND ✗\n";
    }
    
} catch (Throwable $e) {
    echo "12. Database error: ✗\n";
    echo "    " . $e->getMessage() . "\n";
    echo "    " . $e->getFile() . ":" . $e->getLine() . "\n";
}

echo "\n=== TEST COMPLETE ===\n";
