<?php
// Ensure clean JSON output - no errors or warnings should be displayed
error_reporting(0);
@ini_set('display_errors', '0');

// Set JSON header immediately
header('Content-Type: application/json');

// Start output buffering to catch any stray output
ob_start();

try {
    require_once __DIR__ . '/../includes/auth.php';

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        ob_end_clean();
        json_error('Method not allowed.', 405);
    }

    $input = get_json_input();
    $identifier = trim($input['username'] ?? '');
    $password   = (string) ($input['password'] ?? '');

    if ($identifier === '' || $password === '') {
        ob_end_clean();
        json_error('Username/email and password are required.');
    }

    [$locked, $remainingMinutes, $lockMessage] = check_lockout(strtolower($identifier));
    if ($locked) {
        log_security_event('LOGIN_BLOCKED_LOCKOUT', null, $identifier, ['message' => $lockMessage]);
        ob_end_clean();
        json_error($lockMessage ?: "Too many failed attempts. Try again in {$remainingMinutes} minute(s).", 429);
    }

    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
    $stmt->execute([$identifier, $identifier]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        record_failed_login(strtolower($identifier));
        log_security_event('LOGIN_FAILED', $user['id'] ?? null, $identifier);
        ob_end_clean();
        json_error('Invalid username or password.', 401);
    }

    if (!$user['verified']) {
        ob_end_clean();
        json_error('This account is not yet verified. Contact an administrator.', 403);
    }

    // Block accounts under security review even if password is correct
    if (($user['security_status'] ?? 'active') === 'locked_review') {
        log_security_event('LOGIN_BLOCKED_SECURITY_REVIEW', $user['id'], $identifier);
        ob_end_clean();
        json_error('This account is restricted pending security review. Contact an administrator.', 403);
    }

    // Password correct — do NOT establish the full session yet. Regenerate
    // the session id (prevents fixation) and hold a pending-OTP marker only.
    session_regenerate_id(true);
    $_SESSION['otp_pending_user_id'] = $user['id'];
    unset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['role']);

    clear_login_attempts(strtolower($identifier));

    $otpCode = generate_and_store_otp($user['id']);
    $mailed  = send_otp_email($user['email'], $user['name'], $otpCode);
    log_security_event('OTP_SENT', $user['id'], $user['username'], ['mailed' => $mailed]);

    $response = [
        'success'     => true,
        'requiresOtp' => true,
        'otpTtlSeconds' => 60,
        'maskedEmail' => mask_email($user['email']),
    ];

    // DEMO_MODE (config/database.php) surfaces the code directly for local/
    // capstone demos where outbound SMTP isn't configured on shared hosting.
    if (defined('OTP_DEMO_MODE') && OTP_DEMO_MODE === true) {
        $response['debugCode'] = $otpCode;
    }

    // Clear buffer and send response
    ob_end_clean();
    json_response($response);

} catch (Throwable $e) {
    // Clear any output buffer
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Log the error
    error_log('Login error: ' . $e->getMessage());
    
    // Send clean JSON error
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred during login. Please try again.'
    ]);
    exit;
}
