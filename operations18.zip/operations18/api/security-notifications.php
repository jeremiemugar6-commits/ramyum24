<?php
/**
 * Admin security notifications API.
 * Lists pending account lockouts / security reviews and allows unlock/review.
 */
require_once __DIR__ . '/../includes/auth.php';

$user = require_admin_api();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $status = $_GET['status'] ?? 'pending';
    if ($status === 'all') {
        $stmt = $db->query('SELECT * FROM security_notifications ORDER BY created_at DESC LIMIT 200');
    } else {
        $stmt = $db->prepare('SELECT * FROM security_notifications WHERE status = ? ORDER BY created_at DESC LIMIT 100');
        $stmt->execute([$status]);
    }
    $rows = $stmt->fetchAll();
    json_response(['success' => true, 'notifications' => $rows]);
}

if ($method === 'POST') {
    $input = get_json_input();
    $action = $input['action'] ?? '';
    $notificationId = $input['id'] ?? '';
    $notes = trim($input['notes'] ?? '');

    if ($notificationId === '') {
        json_error('Notification id is required.');
    }

    $stmt = $db->prepare('SELECT * FROM security_notifications WHERE id = ?');
    $stmt->execute([$notificationId]);
    $note = $stmt->fetch();
    if (!$note) {
        json_error('Notification not found.', 404);
    }

    if ($action === 'unlock') {
        if (!empty($note['user_id'])) {
            admin_unlock_account($note['user_id'], $user['id'], $notes);
        } else {
            $db->prepare('UPDATE security_notifications SET status = ?, reviewed_by = ?, reviewed_at = NOW(), review_notes = ? WHERE id = ?')
               ->execute(['unlocked', $user['id'], $notes, $notificationId]);
            // Clear by identifier
            if (!empty($note['account_identifier'])) {
                $db->prepare('DELETE FROM login_attempts WHERE identifier = ?')->execute([$note['account_identifier']]);
            }
            log_security_event('ACCOUNT_UNLOCKED_BY_ADMIN', $user['id'], $note['account_identifier'], ['notes' => $notes]);
        }
        json_response(['success' => true, 'message' => 'Account unlocked.']);
    }

    if ($action === 'dismiss' || $action === 'maintain') {
        $db->prepare('UPDATE security_notifications SET status = ?, reviewed_by = ?, reviewed_at = NOW(), review_notes = ? WHERE id = ?')
           ->execute([$action === 'dismiss' ? 'dismissed' : 'reviewed', $user['id'], $notes, $notificationId]);
        log_security_event('SECURITY_NOTIFICATION_REVIEWED', $user['id'], $note['account_identifier'], [
            'action' => $action, 'notes' => $notes
        ]);
        json_response(['success' => true, 'message' => 'Notification updated.']);
    }

    json_error('Unknown action. Use unlock, dismiss, or maintain.');
}

json_error('Method not allowed.', 405);
