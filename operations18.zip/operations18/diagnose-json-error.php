<?php
/**
 * Diagnostic script to identify what's causing HTML output in JSON responses
 */

// Turn on error reporting but log to file instead of display
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/diagnostic.log');

// Start output buffering
ob_start();

echo "Starting diagnostic...\n";

// Test 1: Check PHP version
echo "PHP Version: " . PHP_VERSION . "\n";

// Test 2: Try to load config files
try {
    require_once __DIR__ . '/config/database.php';
    echo "✓ database.php loaded\n";
} catch (Throwable $e) {
    echo "✗ database.php error: " . $e->getMessage() . "\n";
}

try {
    require_once __DIR__ . '/config/mail.php';
    echo "✓ mail.php loaded\n";
} catch (Throwable $e) {
    echo "✗ mail.php error: " . $e->getMessage() . "\n";
}

try {
    require_once __DIR__ . '/includes/functions.php';
    echo "✓ functions.php loaded\n";
} catch (Throwable $e) {
    echo "✗ functions.php error: " . $e->getMessage() . "\n";
}

try {
    require_once __DIR__ . '/includes/auth.php';
    echo "✓ auth.php loaded\n";
} catch (Throwable $e) {
    echo "✗ auth.php error: " . $e->getMessage() . "\n";
}

// Test 3: Try database connection
try {
    $db = getDB();
    echo "✓ Database connected\n";
} catch (Throwable $e) {
    echo "✗ Database connection error: " . $e->getMessage() . "\n";
}

// Test 4: Check session
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "✓ Session started\n";
} else {
    echo "✗ Session not active\n";
}

// Test 5: Test JSON response function
echo "\n=== Testing JSON Response ===\n";
echo "Clearing output buffer and testing json_response()...\n\n";

// Get the diagnostic output
$diagnostic = ob_get_clean();

// Write diagnostic to file
file_put_contents(__DIR__ . '/diagnostic.txt', $diagnostic);

// Now test clean JSON output
json_response([
    'success' => true,
    'message' => 'If you see this, JSON is working!',
    'diagnostic_saved_to' => 'diagnostic.txt'
]);
