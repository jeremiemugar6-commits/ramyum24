/**
 * Purchased / Sold Products Archive
 * Read-only historical transaction records for audit.
 */
import { store } from '../../assets/js/store.js';
import { toast } from '../../assets/js/components/toast.js';

let currentRecords = [];

export async function renderArchive() {
    const user = store.getState().user;
    const role = user?.role || 'staff';
    if (!['admin', 'manager'].includes(role)) {
        return `<div class="card" style="padding:24px;"><p>You do not have permission to view the transaction archive.</p></div>`;
    }

    const html = `
        <div class="page-header" style="margin-bottom:20px;">
            <h1 class="page-title">Purchased / Sold Products Archive</h1>
            <p style="color:var(--text-secondary);">Historical transaction records for documentation and auditing. These records do not modify inventory.</p>
        </div>
        <div class="card" style="padding:20px; margin-bottom:16px;">
            <div style="display:flex; flex-wrap:wrap; gap:12px; align-items:end;">
                <div>
                    <label style="font-size:0.85rem; font-weight:500;">Search</label>
                    <input type="text" id="archSearch" class="form-input" placeholder="Product, SKU, ref, user..." style="min-width:200px;">
                </div>
                <div>
                    <label style="font-size:0.85rem; font-weight:500;">Type</label>
                    <select id="archType" class="form-input">
                        <option value="">All types</option>
                        <option value="purchase">Purchase</option>
                        <option value="sale">Sale</option>
                        <option value="issue">Issue</option>
                        <option value="receive">Receive</option>
                        <option value="adjustment">Adjustment</option>
                        <option value="transfer_out">Transfer Out</option>
                        <option value="transfer_in">Transfer In</option>
                        <option value="return">Return</option>
                    </select>
                </div>
                <div>
                    <label style="font-size:0.85rem; font-weight:500;">From</label>
                    <input type="date" id="archFrom" class="form-input">
                </div>
                <div>
                    <label style="font-size:0.85rem; font-weight:500;">To</label>
                    <input type="date" id="archTo" class="form-input">
                </div>
                <button id="archFilterBtn" style="background:#B91C1C; color:white; border:none; padding:10px 18px; border-radius:6px; cursor:pointer; font-weight:500;">Filter</button>
            </div>
        </div>
        <div class="card" style="padding:0; overflow:auto;">
            <table style="width:100%; border-collapse:collapse; font-size:0.9rem;">
                <thead>
                    <tr style="background:var(--bg-gray); text-align:left;">
                        <th style="padding:12px;">Date/Time</th>
                        <th style="padding:12px;">Product</th>
                        <th style="padding:12px;">SKU</th>
                        <th style="padding:12px;">Qty</th>
                        <th style="padding:12px;">Unit</th>
                        <th style="padding:12px;">Type</th>
                        <th style="padding:12px;">Reference</th>
                        <th style="padding:12px;">User</th>
                        <th style="padding:12px;">Remaining</th>
                    </tr>
                </thead>
                <tbody id="archTableBody">
                    <tr><td colspan="9" style="padding:24px; text-align:center; color:var(--text-secondary);">Loading...</td></tr>
                </tbody>
            </table>
        </div>
    `;

    setTimeout(() => {
        document.getElementById('archFilterBtn')?.addEventListener('click', loadArchive);
        loadArchive();
    }, 50);

    return html;
}

async function loadArchive() {
    const q = document.getElementById('archSearch')?.value || '';
    const type = document.getElementById('archType')?.value || '';
    const from = document.getElementById('archFrom')?.value || '';
    const to = document.getElementById('archTo')?.value || '';
    const params = new URLSearchParams({ limit: '200' });
    if (q) params.set('q', q);
    if (type) params.set('type', type);
    if (from) params.set('from', from);
    if (to) params.set('to', to);

    const tbody = document.getElementById('archTableBody');
    try {
        const res = await fetch('api/transaction-archive.php?' + params.toString());
        const result = await res.json();
        if (!result.success) throw new Error(result.error || 'Failed to load');
        currentRecords = result.records || [];
        if (!currentRecords.length) {
            tbody.innerHTML = `<tr><td colspan="9" style="padding:24px; text-align:center; color:var(--text-secondary);">No archived transactions found.</td></tr>`;
            return;
        }
        tbody.innerHTML = currentRecords.map(r => `
            <tr style="border-top:1px solid var(--border-color);">
                <td style="padding:10px 12px; white-space:nowrap;">${r.transaction_at || ''}</td>
                <td style="padding:10px 12px;">${escapeHtml(r.product_name || '')}</td>
                <td style="padding:10px 12px;">${escapeHtml(r.sku || '—')}</td>
                <td style="padding:10px 12px;">${r.quantity}</td>
                <td style="padding:10px 12px;">${escapeHtml(r.unit || '')}</td>
                <td style="padding:10px 12px;"><span style="padding:2px 8px; border-radius:999px; background:var(--bg-gray); font-size:0.8rem;">${escapeHtml(r.transaction_type || '')}</span></td>
                <td style="padding:10px 12px;">${escapeHtml(r.reference_number || '—')}</td>
                <td style="padding:10px 12px;">${escapeHtml(r.related_user_name || '—')}</td>
                <td style="padding:10px 12px;">${r.remaining_inventory != null ? r.remaining_inventory : '—'}</td>
            </tr>
        `).join('');
    } catch (e) {
        tbody.innerHTML = `<tr><td colspan="9" style="padding:24px; text-align:center; color:#EF4444;">${escapeHtml(e.message)}</td></tr>`;
        toast.show(e.message, 'error');
    }
}

function escapeHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
