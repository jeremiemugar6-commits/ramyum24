/**
 * Cycle Count / Stock Count module
 */
import { DataService } from '../../assets/js/utils/data-service.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';
import { exportToCSV } from '../../assets/js/utils/export-csv.js';

const dataService = new DataService();
let products = [];
let countRows = [];

export async function renderCycleCount() {
    const container = document.getElementById('appContent');
    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Cycle Count</h1>
                <p class="page-subtitle">Count physical stock, compare to system qty, and post adjustments.</p>
            </div>
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <button id="ccExportBtn" class="btn btn-secondary">Export CSV</button>
                <button id="ccPostBtn" class="btn btn-primary" style="background:var(--primary-red); color:#fff; border:none; padding:10px 18px; border-radius:8px; font-weight:600; cursor:pointer;">Post Adjustments</button>
            </div>
        </div>

        <div class="card" style="padding:16px 20px; margin-bottom:20px;">
            <div style="display:flex; flex-wrap:wrap; gap:12px; align-items:center;">
                <input type="text" id="ccSearch" class="form-input" placeholder="Search product or SKU..." style="flex:1; min-width:200px;">
                <select id="ccFilter" class="form-input" style="width:auto;">
                    <option value="all">All products</option>
                    <option value="variance">With variance only</option>
                    <option value="low">Low stock only</option>
                </select>
                <button id="ccLoadBtn" class="btn btn-secondary">Reload</button>
            </div>
        </div>

        <div class="card" style="padding:0; overflow:hidden;">
            <div id="ccTable" style="overflow-x:auto;"></div>
        </div>
    `;

    document.getElementById('ccLoadBtn')?.addEventListener('click', loadData);
    document.getElementById('ccSearch')?.addEventListener('input', renderTable);
    document.getElementById('ccFilter')?.addEventListener('change', renderTable);
    document.getElementById('ccExportBtn')?.addEventListener('click', () => {
        exportToCSV(countRows, [
            { key: 'name', header: 'Product' },
            { key: 'sku', header: 'SKU' },
            { key: 'systemQty', header: 'System Qty' },
            { key: 'countedQty', header: 'Counted Qty' },
            { key: 'variance', header: 'Variance' },
            { key: 'batchNumber', header: 'Batch' },
        ], 'cycle_count');
        toast.show('CSV exported', 'success');
    });
    document.getElementById('ccPostBtn')?.addEventListener('click', postAdjustments);

    await loadData();
}

async function loadData() {
    try {
        products = await dataService.findAll('products');
        countRows = products.filter(p => !p.archived).map(p => ({
            id: p.id,
            name: p.name,
            sku: p.sku || '',
            systemQty: parseFloat(p.stock || 0),
            countedQty: parseFloat(p.stock || 0),
            variance: 0,
            batchNumber: p.batchNumber || '',
            reorderLevel: parseFloat(p.reorderLevel || p.minimumStock || 10),
        }));
        renderTable();
    } catch (e) {
        toast.show('Failed to load products', 'error');
    }
}

function renderTable() {
    const q = (document.getElementById('ccSearch')?.value || '').toLowerCase();
    const filter = document.getElementById('ccFilter')?.value || 'all';

    let rows = countRows.filter(r => {
        const match = !q || r.name.toLowerCase().includes(q) || r.sku.toLowerCase().includes(q);
        if (!match) return false;
        if (filter === 'variance') return r.variance !== 0;
        if (filter === 'low') return r.systemQty <= r.reorderLevel;
        return true;
    });

    const el = document.getElementById('ccTable');
    if (!rows.length) {
        el.innerHTML = `<div style="padding:40px; text-align:center; color:var(--text-muted);">No products match.</div>`;
        return;
    }

    el.innerHTML = `
        <table style="width:100%; border-collapse:collapse; font-size:0.875rem;">
            <thead style="background:var(--bg-gray);">
                <tr>
                    <th style="padding:12px 16px; text-align:left;">Product</th>
                    <th style="padding:12px 16px; text-align:left;">SKU</th>
                    <th style="padding:12px 16px; text-align:right;">System Qty</th>
                    <th style="padding:12px 16px; text-align:right;">Counted Qty</th>
                    <th style="padding:12px 16px; text-align:right;">Variance</th>
                    <th style="padding:12px 16px; text-align:left;">Batch</th>
                </tr>
            </thead>
            <tbody>
                ${rows.map(r => {
                    const varColor = r.variance === 0 ? 'var(--text-muted)' : (r.variance < 0 ? '#DC2626' : '#059669');
                    return `
                    <tr style="border-bottom:1px solid var(--border-color);" data-id="${r.id}">
                        <td style="padding:10px 16px; font-weight:600;">${r.name}</td>
                        <td style="padding:10px 16px; font-family:monospace;">${r.sku}</td>
                        <td style="padding:10px 16px; text-align:right;">${r.systemQty}</td>
                        <td style="padding:10px 16px; text-align:right;">
                            <input type="number" step="0.01" min="0" class="cc-count form-input" data-id="${r.id}"
                                value="${r.countedQty}" style="width:100px; text-align:right; padding:6px 8px;">
                        </td>
                        <td style="padding:10px 16px; text-align:right; font-weight:700; color:${varColor};" class="cc-var" data-id="${r.id}">${r.variance}</td>
                        <td style="padding:10px 16px;">${r.batchNumber || '—'}</td>
                    </tr>`;
                }).join('')}
            </tbody>
        </table>
    `;

    el.querySelectorAll('.cc-count').forEach(input => {
        input.addEventListener('change', () => {
            const id = input.dataset.id;
            const row = countRows.find(r => r.id === id);
            if (!row) return;
            row.countedQty = parseFloat(input.value) || 0;
            row.variance = Math.round((row.countedQty - row.systemQty) * 100) / 100;
            const varEl = el.querySelector(`.cc-var[data-id="${id}"]`);
            if (varEl) {
                varEl.textContent = row.variance;
                varEl.style.color = row.variance === 0 ? 'var(--text-muted)' : (row.variance < 0 ? '#DC2626' : '#059669');
            }
        });
    });
}

async function postAdjustments() {
    const variances = countRows.filter(r => r.variance !== 0);
    if (!variances.length) {
        toast.show('No variances to post.', 'info');
        return;
    }

    const confirmed = confirm(`Post ${variances.length} stock adjustment(s) for counted variances?`);
    if (!confirmed) return;

    const user = store.getState().user;
    let ok = 0, fail = 0;

    for (const row of variances) {
        try {
            const product = products.find(p => p.id === row.id);
            if (!product) { fail++; continue; }

            await dataService.update('products', row.id, {
                ...product,
                stock: row.countedQty,
                lastUpdated: new Date().toISOString(),
            });

            await dataService.create('inventory_movements', {
                id: `cc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
                productId: row.id,
                productName: row.name,
                sku: row.sku,
                date: new Date().toISOString(),
                type: 'Adjustment',
                referenceType: 'CycleCount',
                quantity: Math.abs(row.variance),
                previousBalance: row.systemQty,
                newBalance: row.countedQty,
                change: row.variance,
                reason: 'Inventory Count',
                notes: `Cycle count variance: system ${row.systemQty} → counted ${row.countedQty}`,
                user: user?.name || user?.username || 'System',
                batchNumber: row.batchNumber || null,
            });
            ok++;
        } catch (e) {
            console.error(e);
            fail++;
        }
    }

    toast.show(`Posted ${ok} adjustment(s)${fail ? `, ${fail} failed` : ''}.`, ok ? 'success' : 'error');
    await loadData();
}
