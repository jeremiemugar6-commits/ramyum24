/**
 * Stock Status Utility
 * Centralized logic for automatic stock status calculation
 * Mirrors server-side logic in includes/stock-status.php
 */

export class StockStatus {
    /**
     * @param {number} currentStock
     * @param {number|null} minimumStock
     * @param {number|null} maximumStock
     * @returns {string}
     */
    static getStatus(currentStock, minimumStock = null, maximumStock = null) {
        const stock = parseFloat(currentStock) || 0;

        if (stock <= 0) {
            return 'Out of Stock';
        }

        const hasMin = minimumStock !== null && minimumStock !== '' && !isNaN(parseFloat(minimumStock));
        const hasMax = maximumStock !== null && maximumStock !== '' && !isNaN(parseFloat(maximumStock));

        if (hasMin || hasMax) {
            const min = hasMin ? parseFloat(minimumStock) : 0;
            const max = hasMax ? parseFloat(maximumStock) : Number.MAX_SAFE_INTEGER;
            if (stock < min) return 'Low Stock';
            if (stock > max) return 'Overstock';
            return 'In Stock';
        }

        if (stock < 21) return 'Low Stock';
        if (stock <= 100) return 'In Stock';
        return 'Overstock';
    }

    static getEmoji(status) {
        switch (status) {
            case 'Out of Stock': return '🔴';
            case 'Low Stock': return '🟠';
            case 'In Stock': return '🟢';
            case 'Overstock': return '🔵';
            default: return '⚪';
        }
    }

    static getBadgeClass(status) {
        switch (status) {
            case 'Out of Stock': return 'badge-out-of-stock';
            case 'Low Stock': return 'badge-low-stock';
            case 'In Stock': return 'badge-in-stock';
            case 'Overstock': return 'badge-overstock';
            default: return 'badge-default';
        }
    }

    static getBadgeHtml(currentStock, minimumStock = null, maximumStock = null) {
        const status = this.getStatus(currentStock, minimumStock, maximumStock);
        const emoji = this.getEmoji(status);
        const cls = this.getBadgeClass(status);
        return `<span class="stock-badge ${cls}">${emoji} ${status}</span>`;
    }

    static getProductStatus(product) {
        if (!product) return 'Out of Stock';
        return this.getStatus(
            product.stock,
            product.minimumStock ?? product.minStock ?? null,
            product.maximumStock ?? product.maxStock ?? null
        );
    }
}

export default StockStatus;
