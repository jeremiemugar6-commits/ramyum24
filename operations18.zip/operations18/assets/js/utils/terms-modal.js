/**
 * Terms and Conditions acceptance modal.
 * Checkbox is unchecked by default; user must accept before proceeding.
 */
import { modal } from '../components/modal.js';
import { toast } from '../components/toast.js';

/**
 * Ensures the user has accepted the latest terms for the given context.
 * Shows a modal if acceptance is required.
 * @param {string} appliesTo e.g. 'inventory_transaction' | 'general'
 * @returns {Promise<boolean>} true if accepted / already accepted
 */
export async function ensureTermsAccepted(appliesTo = 'inventory_transaction') {
    try {
        const res = await fetch(`api/terms.php?action=check&applies_to=${encodeURIComponent(appliesTo)}`);
        const data = await res.json();
        if (!data.success) return true; // fail open if terms not configured
        if (!data.required || !data.terms) return true;

        return await new Promise((resolve) => {
            const terms = data.terms;
            const body = `
                <div style="max-height:320px; overflow:auto; padding:12px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-gray); white-space:pre-wrap; font-size:0.9rem; line-height:1.5;">
${escapeHtml(terms.content || '')}
                </div>
                <label style="display:flex; align-items:flex-start; gap:10px; margin-top:16px; cursor:pointer;">
                    <input type="checkbox" id="termsAcceptCb" style="margin-top:3px;" />
                    <span>I have read and accept these terms (version ${escapeHtml(terms.version || '')}).</span>
                </label>
                <p id="termsAcceptError" style="color:#EF4444; font-size:0.85rem; margin-top:8px; display:none;">You must accept the terms to continue.</p>
            `;
            modal.open(terms.title || 'Terms and Conditions', body, {
                confirmText: 'Accept & Continue',
                cancelText: 'Cancel',
                onConfirm: async () => {
                    const cb = document.getElementById('termsAcceptCb');
                    if (!cb || !cb.checked) {
                        const err = document.getElementById('termsAcceptError');
                        if (err) err.style.display = 'block';
                        return false;
                    }
                    try {
                        const acc = await fetch('api/terms.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'accept', terms_id: terms.id })
                        });
                        const result = await acc.json();
                        if (!result.success) throw new Error(result.error || 'Failed to record acceptance');
                        resolve(true);
                        return true;
                    } catch (e) {
                        toast.show(e.message, 'error');
                        return false;
                    }
                },
                onCancel: () => {
                    resolve(false);
                    return true;
                }
            });
        });
    } catch (e) {
        console.warn('Terms check failed', e);
        return true;
    }
}

function escapeHtml(s) {
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

export default { ensureTermsAccepted };
